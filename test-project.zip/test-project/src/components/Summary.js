import React from 'react'

function Summary() {
  return (
   <div >
    <h1 className="heading">Summary</h1>
   </div> 
  )
}

export default Summary