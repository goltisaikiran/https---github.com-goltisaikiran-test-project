import React from 'react'

function Voltrend() {
 
  return (
    <div >
    <h1 className="heading">Voltrend</h1> 

    </div>
  )
}

export default Voltrend