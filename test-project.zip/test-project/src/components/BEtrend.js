import React from 'react'

function BEtrend() {
  return (
    <div  >
    <h1 className="heading">BEtrend</h1>
   </div> 
  )
}

export default BEtrend