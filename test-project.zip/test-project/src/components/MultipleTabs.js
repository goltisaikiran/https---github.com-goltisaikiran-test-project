import React from 'react'

function MultipleTabs() {
  return (
    <div  >
    <h1 className="heading">MultipleTabs</h1>
   </div> 
  )
}

export default MultipleTabs